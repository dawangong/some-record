window.onload = function() {
	//微信二维码的显示
	var weixin = document.getElementById("weixin");
	var ewm = document.getElementsByClassName("youewm")[0];
	weixin.onmouseover = function() {
		ewm.style.display = 'block';
	}
	weixin.onmouseout = function() {
		ewm.style.display = 'none';
	}
	//商家分类的子菜单配置
	var list1 = document.getElementsByClassName("listbox")[0];
	var father = document.getElementsByClassName("father")[0];
	var lis = father.getElementsByTagName('li');
	//主菜单的样式变化
	father.onclick = function(ev) {
		var e = ev;
		var target = e.target || e.srcElement;
		for(var i = 0; i < lis.length; i++) {
			lis[i].style.background = 'white';
			lis[i].style.color = '#666666';
		}
		if(target.tagName == 'LI') {
			target.style.background = '#F6F6F6';
			target.style.color = '#666666';
			//取消和重置hover效果
			lis[0].className = 'rm';
			if(target.innerHTML == '全部商家') {
				target.style.background = '#0089DC';
				target.style.color = 'white';
				target.className = 'zero';
			}

			//子菜单的显示和更换
			var uls = document.getElementsByClassName('hid');

			switch(target.innerHTML) {
				case '全部商家':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var quanbu = document.getElementById("quanbu");
					quanbu.style.display = 'block';
					control(quanbu);
					break;
				case '美食':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var meishi = document.getElementById("meishi");
					meishi.style.display = 'block';
					control(meishi);
					break;
				case '快餐便当':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var kuaican = document.getElementById("kuaican");
					kuaican.style.display = 'block';
					control(kuaican);
					break;
				case '特色菜系':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var tese = document.getElementById("tese");
					tese.style.display = 'block';
					control(tese);
					break;
				case '异国料理':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var yiguo = document.getElementById("yiguo");
					yiguo.style.display = 'block';
					control(yiguo);
					break;
				case '小吃夜宵':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var xiaochi = document.getElementById("xiaochi");
					xiaochi.style.display = 'block';
					control(xiaochi);
					break;
				case '甜品饮品':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var tianpin = document.getElementById("tianpin");
					tianpin.style.display = 'block';
					control(tianpin);
					break;
				case '果蔬生鲜':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var guoshu = document.getElementById("guoshu");
					guoshu.style.display = 'block';
					control(guoshu);
					break;
				case '商店超市':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var shangdain = document.getElementById("shangdian");
					shangdain.style.display = 'block';
					control(shangdian);
					break;
				case '浪漫鲜花':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var langman = document.getElementById("langman");
					langman.style.display = 'block';
					control(langman);
					break;
				case '医药健康':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var yiyao = document.getElementById("yiyao");
					yiyao.style.display = 'block';
					control(yiyao);
					break;
				case '早餐':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var zaocan = document.getElementById("zaocan");
					zaocan.style.display = 'block';
					control(zaocan);
					break;
				case '午餐':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var wucan = document.getElementById("wucan");
					wucan.style.display = 'block';
					control(wucan);
					break;
				case '下午茶':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var xiawu = document.getElementById("xiawu");
					xiawu.style.display = 'block';
					control(xiawu);
					break;
				case '晚餐':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var wancan = document.getElementById("wancan");
					wancan.style.display = 'block';
					control(wancan);
					break;
				case '夜宵':
					for(var i = 0; i < uls.length; i++) {
						uls[i].style.display = 'none';
					}
					var yexiao = document.getElementById("yexiao");
					yexiao.style.display = 'block';
					control(yexiao);
					break;
			}

		}

	}
	//用来操作子菜单变化的函数
	function control(obj) {
		obj.onclick = function(ev) {
			var e = ev;
			var target = e.target || e.srcElement;
			var lis = obj.getElementsByTagName('li');
			for(var i = 0; i < lis.length; i++) {
				lis[i].style.background = '#F6F6F6';
				lis[i].style.color = '#666666';
			}
			if(target.tagName == 'LI') {
				target.style.background = '#0089DC';
				target.style.color = '#F7F7F7';
			}
		}
	}
	//悬浮层显示
	var floats = document.getElementsByClassName('floats-box');
	var shopTypes = document.getElementsByClassName('shop-type');

	for(var j = 0; j < shopTypes.length; j++) {
		shopTypes[j].index = j;
		shopTypes[j].onmouseover = function() {

			floats[this.index].style.display = 'block';
			floats[this.index].style.zIndex = 5;
		}

		shopTypes[j].onmouseout = function() {

			floats[this.index].style.display = 'none';
			floats[this.index].style.zIndex = 0;
		}

	}
	//onmouseenter取消显示冲突
	for(var i = 0; i < floats.length; i++) {
		floats[i].onmouseenter = function() {
			this.style.display = 'none';
		}

	}

}