function add (a='hi') {
	console.log(a);
}
add('ni');