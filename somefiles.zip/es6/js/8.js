let add=(a,b) => a+b;
let result=add(3,5);
console.log(result);