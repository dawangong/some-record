//class Animal {
//  constructor(){
//      this.type = 'animal'
//  }
//  says(say){
//      setTimeout(function(){
//          console.log(this.type + ' says ' + say)
//      }, 1000)
//  }
//}


// var animal = new Animal()
// animal.says('hi');
//
//
//class Animal {
//  constructor(){
//      this.type = 'animal'
//  }
//  says(say){
//  	var that=this;
//      setTimeout(function(){
//          console.log(that.type + ' says ' + say)
//      }, 1000)
//  }
//}
//
// var animal = new Animal()
// animal.says('hi');


class Animal {
    constructor(){
        this.type = 'animal'
    }
    says(say){
        setTimeout(() => {
            console.log(this.type + ' says ' + say)
        }, 1000)
    }
}

 var animal = new Animal()
 animal.says('hi');