function add (...a) {
	return a;
}

let arr=add(1,4,6,7,8,10);
console.log(arr);