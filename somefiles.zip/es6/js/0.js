window.onload = function() {
//	var a = [];
//	for(var i = 0; i < 10; i++) {
//		a[i] = function() {
//			console.log(i);
//		};
//	}
//	a[6](); // 10
//	
//	var a = [];
//	for(let i = 0; i < 10; i++) {
//		a[i] = function() {
//			console.log(i);
//		};
//	}
//	a[6](); // 6
//	
//	
//	
//	for(let i = 0; i < 3; i++) {
//		let i = 'abc';
//		console.log(i);
//	}
//	// abc
//	// abc
//	// abc
//	//上面代码正确运行，输出了3次abc。这表明函数内部的变量i与循环变量i不在同一个作用域，有各自单独的作用域。
	
	
}