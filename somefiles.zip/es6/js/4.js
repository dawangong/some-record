let [a,b,c]=['ni','hao','ma'];
console.log(a,b,c);
