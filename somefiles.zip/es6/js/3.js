var ps=document.getElementById("p");
var odate=new Date();
var time=odate.getTime();
p.append(`试一下${time}`);