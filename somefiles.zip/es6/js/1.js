class Person{
	constructor() {
	    this.type='people';
	}
	say(age){
		console.log('我今年'+age+'岁');
	}
	go(){
		console.log(this.type);
	}
}

class Boy extends Person{
	constructor(){
		super();
		this.type='child';
	}
}

let xiaoming=new Boy();
xiaoming.go();
