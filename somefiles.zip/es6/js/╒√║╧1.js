var qc=arr => {
	for (let i=0;i<arr.length;i++) {
		for (let j=i+1;j<arr.length;j++) {
			if(arr [i]==arr[j]){
				arr.splice(j,1);
				j--;
			}
		}
	}
	return arr;
}
let arra=qc([3,6,7,8,3,5,6,7,8,4,2]);
console.log(arra);