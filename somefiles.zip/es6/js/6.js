function add(...a) {
	console.log(a);
}
add(1,2,4,5,6);//[1,2,4,5,6]
