var app=angular.module('ap', []);

app.controller('ctrl', function($scope) {
	$scope.arr = ['你', '猜', '吧'];
	$scope.name='mery';
})

app.controller('ctrl2', function($scope) {
	$scope.value=0;
})